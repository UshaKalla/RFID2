// *****************************************************************************
// BitTagMonitor
// -------------
// This Arduino program monitors the output of the filter built in RFID Lab
// C in order to determine if a bit tag is in the vicinity.  It will modulate
// an LED and buzzer to indicate relative field strength.  The faster the tones
// (and LED blinking), then the stronger the coupling between the scanner and
// tag coils.
// -----------------------------------------------------------------------------
// Created by:  Curtis Ratzlaff  10/19/2012
// Copyright (C) 2012, 2013 by Carnegie Mellon University
// *****************************************************************************

// The port assignments which should match your circuit
const int redPort     = 6;
const int yellowPort  = 7;
const int greenPort   = 8;
const int buzzerPort  = 9;
const int analogPort  = A0;

// Buzzers work best at a certain frequency, so modify it here, if necessary
const int buzzerFreq = 2000;

// Maximum value under which we start to recognize the presence of a tag.
// This gets set by the calibration routine during setup.
int tagThreshold = 0;

// Forward declarations. Find these functions at the end of this file.
void buzz(int buzzDuration, int buzzFreq = buzzerFreq, int buzzPin = buzzerPort);
int calBitTagMonitor(int nLoops);
void clearAll();
void testLedsAndPorts();


// LED control functions. Pass true to turn on an LED; false, to turn it off.
void turnOnGreen(bool on = true)  { digitalWrite(greenPort,  on); }
void turnOnRed(bool on = true)    { digitalWrite(redPort,    on); }
void turnOnYellow(bool on = true) { digitalWrite(yellowPort, on); }

// This will run once immediately after a power up or by pressing
// the Arduino's RESET button
void setup()
{
  // Configure the Arduino serial monitor and ports as needed
  Serial.begin(9600);
  
  // Define digital I/O port directions
  pinMode(redPort,    OUTPUT);
  pinMode(yellowPort, OUTPUT);
  pinMode(greenPort,  OUTPUT);
  pinMode(buzzerPort, OUTPUT);
  
  // Calibrate levels with NO RFID tag in proximity
  tagThreshold = calBitTagMonitor(5000);
  
  // Let user know whether LED and buzzer is working properly...
  testLedsAndBuzzer();
}

// This runs forever after setup is done
void loop()
{
  // Read the analog level at the ADC input. If it's below the expected
  // quiescent level, then we recognize a tag and modulate buzzer and
  // LED as a function of the level.
  int a2d = analogRead(analogPort); 
  if (a2d < tagThreshold) {
    buzz(30);
    turnOnRed(true);   
    delay((a2d >> 2) + 20);
    turnOnRed(false);
  }
}

// Sounds the buzzer at specified frequency for specified duration.
// This function will not return until buzzer duration has elapsed.
void buzz(int buzzDuration, int buzzFreq, int buzzPin)
{
  const int buzzHalfPeriod = 500000/buzzFreq;  //in microseconds
  long tStart = millis();
  do {
    digitalWrite(buzzerPort, HIGH);
    delayMicroseconds(buzzHalfPeriod);
    digitalWrite(buzzerPort, LOW);
    delayMicroseconds(buzzHalfPeriod);
  } while (millis()-tStart < buzzDuration);
}


// This calibrates the bit tag threshold, which is the level under which
// we will recognize the presence of a bit tag or when there is no discernible
// data being transmitted.
int calBitTagMonitor(int nLoops)
{
  Serial.println("Bit tag detector calibrating...");

  // Here, we assume there is no bit tag present, and we calibrate the
  // average level read from the ADC
  long int total = 0;
  for (int i = 0; i < nLoops; i++) {
    // Read the ADC value and accumulate for later averaging
    int a2d = analogRead(analogPort);
    total += a2d;
  }
  // Compute the average across all the samples, then reduce it a bit to
  // get our threshold
  int tagThreshold = int(total/nLoops);
  tagThreshold -= tagThreshold/16;
  Serial.print("Bit tag threshold calibrated at ");
  Serial.println(tagThreshold);
  return tagThreshold;
}

// Turn off all LED's
void clearAll()
{
  turnOnRed(false);
  turnOnGreen(false);
  turnOnYellow(false);
}

// This function performs the following actions to allow the user to verify
// proper opertion of the LEDs and buzzer:
//
// * Disables all LEDs and the buzzer
// * Toggles all LEDs on then off, with a 500 ms delay between
// * Sequences through the LEDs, one at at time with short beep after
//   turning each one on.  Total of 500 ms between each beep and LED.
//
void testLedsAndBuzzer()
{
  clearAll();
  bool enable = true;
  for (int i = 0; i < 2; i++) {
    turnOnRed(enable);
    turnOnYellow(enable);
    turnOnGreen(enable);
    enable = !enable;
    delay(500);
  }
  
  clearAll(); // everything should be off, but let's be sure
  for (int i = 0; i < 1; i++) {
    turnOnRed();
    buzz(100);
    delay(400);

    turnOnYellow();
    buzz(100);
    delay(400);
    
    turnOnGreen();
    buzz(100);
    delay(400);
  }
  clearAll();//And turn everything off again
}

