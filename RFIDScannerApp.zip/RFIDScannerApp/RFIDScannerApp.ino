// *****************************************************************************
// RFID Scanner Setup and Main Loop
// --------------------------------
// This module runs the RFID scanner, continuously scanning for valid ids.
// -----------------------------------------------------------------------------
// Created by:  Curtis Ratzlaff  10/19/2012
// Copyright (C) 2012, 2013 by Carnegie Mellon University
// *****************************************************************************

#include "RFIDScanner.h"
#include "RFIDOutput.h"


// Forward declarations. Look for the implementations at the end of this file.
int calBitTagMonitor(int nLoops);
void setupADC();

// Set ADC pin here
const int analogPin = A0;

// Declare the one and only scanner. It will be setup later.
RFIDScanner theScanner;

// Setup the output controller using default settings
RFIDOutput rfidOutput;

// Setting this to  -1 will disable bit tag detection. Setting to zero
// enables it and also causes it to be written with the reference level
// used for bit tag detection.
int bitThresh = 0;

// The setup routine runs after a power up or if you press the Reset button
void setup() {
  // This sets the conversion rate of the ADC to a higher rate than the default
  setupADC();

  // Setup the scanner software to match our hardware. We start by reloading any
  // defaults.  The only change we need to make from that is to tell the software
  // that our input signal (from the demodulation filter) is inverted (because we
  // take it from the top the capacitor).
  theScanner.setDefaults();
  theScanner._invert = true;

  // initialize the serial monitor
  Serial.begin(9600);

  // setup LED and buzzer states
  rfidOutput.reset();

  // Run a test of the LED's and buzzer to let user know whether their LED's and
  // buzzer are connected correctly
  rfidOutput.testLedsAndBuzzer();
  
  // We don't look for bit tags if bitThresh is negative
  if (bitThresh == 0) {
    bitThresh = calBitTagMonitor(2500);
  }
  Serial.println("RFID Scanner Reset");
}


// This runs over and over forever once setup has completed
void loop() {
  const int oneSecond = 1000;  //milliseconds per second
  const int maxLoopsTilTimeCheck = 1000;
  
  int64_t lastId = 0;
  long tLoopStart = millis(), tValidId = 0, tLastValidId = 0;
  long bitLvlTime = 0, a2dTot = 0;
  int nLoops = 0;

  do {
    // Read a sample from the ADC and send it to the scanner for processing
    int a2d = analogRead(analogPin);
    uint64_t id = theScanner.sample(a2d);

    // Zero is returned if we do not yet have an id
    if (id) {
      long tValidId = millis();
      tLoopStart = tValidId;

      // We only echo the id if we haven't seen it previously for
      // at least one second (1000 ms)
      if (id != lastId || tValidId-tLastValidId > oneSecond) {
        rfidOutput.indicateValidId(id);
      }

      // Register this id and log its acquisition time
      lastId = id;
      tLastValidId = tValidId;
      nLoops = 0;
    } else if (++nLoops > maxLoopsTilTimeCheck && millis()-tLastValidId > oneSecond) {
      // Update output state after a certain time when we have had no
      // valid id for at least a second.
      rfidOutput.updateState(theScanner.getState());
      nLoops = 0;

      // If bitThresh has been set, then this will check for the presence
      // of a bit tag, which is recognized if we see no more than half the
      // normal (tagless) quiescent level for at least 20ms.  We sound the
      // buzzer in manner to indicate relative proximity.
      if (a2d < bitThresh) {
        if (bitLvlTime == 0) bitLvlTime = millis();
        else if (millis()-bitLvlTime > 20 && theScanner.getState() <= 1) {
          do {
            // Sound the buzzer and turn on the red LED
            rfidOutput.buzz(30);
            rfidOutput.turnOnRed();
            
            // Read the filter output level and delay an amount proportional to it,
            // then turn off the LED
            a2d = analogRead(analogPin);
            delay((a2d >> 2) + 20);
            rfidOutput.turnOnRed(false);
            
          } while (a2d < bitThresh);
          
          bitLvlTime = millis();
        }
      }
    }
  } while (millis()-tLoopStart < oneSecond);
  
  tLoopStart = millis();
  theScanner.reset();
}

// This calibrates the bit tag threshold, which is the level under which
// we will recognize the presence of a bit tag when there is no discernible
// data being transmitted.
int calBitTagMonitor(int nLoops)
{
  Serial.println("Bit tag detector calibrating...");

  // Here, we assume there is no bit tag present, and we calibrate the
  // average level read from the ADC
  long int total = 0;
  for (int i = 0; i < nLoops; i++) {
    // Read the ADC value and accumulate for later averaging
    int a2d = analogRead(analogPin);
    total += a2d;
  }
  // Compute the average across all the samples, then reduce it a bit to
  // get our threshold
  int tagThreshold = int(total/nLoops);
  tagThreshold -= tagThreshold/16;
  Serial.print("Bit tag threshold calibrated at ");
  Serial.println(tagThreshold);
  return tagThreshold;
}


// These macros allow us to set or clear register bits of Atmel controller
#ifndef cbi
#define cbi(sfr, bit) (_SFR_BYTE(sfr) &= ~_BV(bit))
#endif
#ifndef sbi
#define sbi(sfr, bit) (_SFR_BYTE(sfr) |= _BV(bit))
#endif


// Used to setup the conversion rate for the A to D converter. The default
// clock prescale normally allows us to do conversions at a maximum rate of 8k-10k
// samples per second.  We increase the conversion rate by reducing the prescale
// factor.  Keep in mind that the base clock rate is 16 MHz. That gets divided
// by the prescale factor (selected here). The resulting clock rate drives a
// successive approximation A/D converter which requires about 13 clocks to
// complete a conversion.  So our approximate sampling rate will be 16MHz/prescale/13
// samples per second.

void setupADC()
{
  // set prescale to 32 (101) or 16 (100)
  sbi(ADCSRA,ADPS2);
  cbi(ADCSRA,ADPS1);
  cbi(ADCSRA,ADPS0); 
}




