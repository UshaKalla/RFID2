// *****************************************************************************
// RFIDOutput
// ----------
// Refer to the header file for the purpose of this class.
// -----------------------------------------------------------------------------
// Created by:  Curtis Ratzlaff  10/19/2012
// Copyright (C) 2012, 2013 by Carnegie Mellon University
// *****************************************************************************

// Constructor
RFIDOutput::RFIDOutput(int redPort, int yellowPort, int greenPort, int buzzerPort)
{
  _ports[RED]    = redPort;
  _ports[YELLOW] = yellowPort;
  _ports[GREEN]  = greenPort;
  _ports[BUZZER] = buzzerPort;
  
  _buzzDuration  = 500;        //default buzzer duration in ms
  _buzzFreq      = 2000;       //default approx buzzer resonant freq
}


// Sounds the buzzer, if enabled and valid. This blocks for the duration
// of the buzzer tone.
void RFIDOutput::buzz(int buzzDuration)
{
  if (buzzDuration == 0) buzzDuration = _buzzDuration;
  int p = _ports[BUZZER];
  if (p > 0 && _buzzFreq > 0) {

    // Assuming a 50% duty cycle, compute buzzer hi/low periods using
    // the desired operating frequency
    int buzzHalfPeriod = 500000 / _buzzFreq;  //in microseconds
    long tStart = millis();
    do {
      digitalWrite(p, HIGH);
      delayMicroseconds(buzzHalfPeriod);
      digitalWrite(p, LOW);
      delayMicroseconds(buzzHalfPeriod);
    } while (millis()-tStart < buzzDuration);
  }
}

// The current Arduino functions do not allow for the output of more than
// 32 bit integers, so this was written to display our 40-bit id's using a
// 64 bit unsigned integer.
//
// 'v' is the value to print. 'fmt' may be HEX or DEC (defaulting to DEC),
// and 'nDigs' may specify the maximum expected number of digits. If the
// value is less than that, then zeros will pad the beginning.
void RFIDOutput::print64(uint64_t v, int fmt, int nDigs)
{
  char digits[64];

  int n = 0;
  switch (fmt) {
    
  // convert 'v' to string of hex digits
  case HEX:
    do {
      digits[n++] = (v & 0xf);
      v >>= 4;
    } while (v);
    break;

  // convert 'v' to string of decimal digits
  case DEC:
    do {
      digits[n++] = v % 10;
      v = v/10;
    } while (v);
    break;

  default:
    print64(v, DEC);
    break;
  }

  // If desired (and possible), pad with leading zeros
  int nZeros = nDigs - n;
  while (nZeros-- > 0) {
    Serial.print('0');
  }   
  
  // Output the final digits in proper order
  while (n--) {
    Serial.print(int(digits[n]), fmt);
  }
}

// Used to set the default buzzer duration and frequency
void RFIDOutput::setBuzzerDuration(int durationMs, int buzzFreq)
{
  _buzzDuration = max(durationMs, 0);
  _buzzFreq = max(buzzFreq, 0);
}


// This function performs the following actions to allow the user to verify
// proper opertion of the LEDs and buzzer:
//
// * Disables all LEDs and the buzzer
// * Toggles all LEDs on then off, with a 500 ms delay between
// * Sequences through the LEDs, one on at at time with short beep after
//   turning each one on.  Total of 500 ms between each beep and LED.
//
void RFIDOutput::testLedsAndBuzzer()
{
  clearAll();
  for (int i = 0; i < 2; i++) {
    toggleState(RED);
    toggleState(YELLOW);
    toggleState(GREEN);
    delay(500);
  }
  
  clearAll(); // everything should be off, but let's be sure
  for (int i = 0; i < 1; i++) {
    turnOnRed();
    buzz(100);
    delay(400);

    turnOnYellow();
    buzz(100);
    delay(400);
    
    turnOnGreen();
    buzz(100);
    delay(400);
  }
  clearAll(); //Turn everything off again
}

