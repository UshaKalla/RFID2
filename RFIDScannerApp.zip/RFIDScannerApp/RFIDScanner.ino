// *****************************************************************************
// RFIDScanner
// -----------
// Implementation for the EM4102 type scanner
// -----------------------------------------------------------------------------
// Created by:  Curtis Ratzlaff  10/19/2012
// Copyright (C) 2012, 2013 by Carnegie Mellon University
// *****************************************************************************


#include "RFIDScanner.h"

// The constructor
RFIDScanner::RFIDScanner()
{
  init();
  setDefaults();
}

// Sets up this instance to construction state
void RFIDScanner::init()
{
  memset(this, 0, sizeof(*this));
}

// This preprocesses a new sample. It attempts in a crude way to filter out
// invalid values and also to attempts to track the mean value of the signal
// so that we can track signals whose dc offsets tend to fluctuate. This occurs
// as you move your tag around in the field. Moving it to quickly will cause a
// loss of signal or an invalid mean.  To do this really well, we should consider
// sampling at a higher rate and implementing a bandpass digital filter.
int16_t RFIDScanner::logSample(int16_t lvl, int8_t& dir, bool& bit)
{
  if (_invert) lvl = -lvl;

  dir = 0;
  bit = false;

  _cur0Min = min(_cur0Min, lvl);
  _cur1Max = max(_cur1Max, lvl);

  if (_state >= stCalBitLen) {
    bit = (lvl >= _avgLvl);
    dir = bit - _lastBit;
    _lastBit = bit;
    _bitLen++;

    if (dir) {                    
      _lastBitLen = _bitLen;
      _bitLen = 0;                    
      if (_state > stCalBitLen) {
        if (_lastBitLen < _bitLenMin) {
          if (_isMid) _isMid = false;
          else {
            _isMid = true;
            dir = 0;
          }
        } else {
          _isMid = false;
        }
      }

      // Update min/max levels and average
      if (dir < 0) {
        _prev1Max = _cur1Max;
        _cur1Max = SHRT_MIN;
        _avgLvl = (_prev0Min + _prev1Max)/2;
      } else if (dir > 0) {
        // Got pos-going crossing the avg. Close out zero.
        _prev0Min = _cur0Min;
        _cur0Min = SHRT_MAX;
        _avgLvl = (_prev0Min + _prev1Max)/2;
      }
    } else if (_state > stCalBitLen && _bitLen > 4*_bitLenMax) {
      // No transitions for a long time, so reset to recalibrate
      setState(stReset);
    }
  }
  return lvl;
}

// Calling reset merely throws us back to the reset state which will eventually
// cause the software to restart things.
void RFIDScanner::reset()
{
  setState(stReset);
}

// *****************************************************************************
// This processes each sample in real-time.  It returns zero if no valid
// id has been recognized yet. Non-zero otherwise.
// *****************************************************************************
uint64_t RFIDScanner::sample(int16_t lvl)
{
  bool bit, idReady = false;
  int8_t dir;
  lvl = logSample(lvl, dir, bit);

  // If we are out of the reset/cal state, where we are only interested in
  // real (data) bit transitions, hence we ignore an unchanged signal level.
  if (dir == 0 && _state >= stSearchHdr) {
    return 0;
  }

  switch (State(_state)) {
  case stReset:
    // The reset state is only used to setup initial values
    _isMid      = _lastBit = false;
    _cur0Min    = _cur1Max = lvl;
    _nHdrBits   = 0;
    _nIdBits    = 0;
    //
    setState(stCalLevel);
    break;

  case stCalLevel:
    // We enter this state if we are still calibrating signal levels.
    if (_cur1Max - _cur0Min >= _minPeakToPeak) {
      if (++_subState >= _minCalCount) {
        _avgLvl = (_cur0Min + _cur1Max)/2;
        _prev0Min = _cur0Min;
        _prev1Max = _cur1Max;

        setState(stCalBitLen);
      }
    }
    break;

  case stCalBitLen:
    // We enter this state if still calibrating bit lengths. Basically, we
    // are trying to figure out minimum length for a "long" bit.  Anything
    // longer than that will register a full bit period. The _subState is used
    // as counter here until it's time to switch to a new state.
    if (_subState < 2) {
      if (dir) {
        _bitLen    = _bitLenMax = 0;
        _bitLenMin = UCHAR_MAX;
        _subState++;
      }
    } 
    else if (_subState < 99) {
      if (dir) {
        _bitLenMin = min(_lastBitLen, _bitLenMin);
        _bitLenMax = max(_lastBitLen, _bitLenMax);                   
        if (_bitLenMin >= 2 && 2*_bitLenMin <= _bitLenMax) {
          // Min length for a full bit
          _bitLenMin = (_bitLenMin + _bitLenMax) >> 1;
          // indicate that we have a valid long bit length
          _subState = 99;
        }
      }
    }

    if (dir > 0 && _lastBitLen >= _bitLenMin && _subState == 99) {
      // indicate that we have found our first potential starting bit of the
      // 9-bit long string of 1's
      _nHdrBits = 1;
      setState(stSearchHdr);
    }
    break;

  case stSearchHdr:
    // This state is entered as long as we are still searching for the nine
    // consecutive header bits.
    if (bit) {
      if (++_nHdrBits == 9) {
        // We have all 9 valid header bits, so setup to start registering
        // the id bits and the associated parity bits.
        _rowParity = false;
        _colParity[0] = _colParity[1] = _colParity[2] = _colParity[3] = false;
        _id = 0;
        _nIdBits = 0;
        setState(stGetPacket);

        // setup for restart of header search
        _nHdrBits = 0;
      }
    } else {
      _nHdrBits = 0;
    }
    break;

  case stGetPacket:
    // We enter this state for every data bit and parity bit until we either get
    // a valid id or until we see a parity error.  The later will knock us to
    // back to another state.
    {
      _rowParity ^= bit;
      unsigned col = _subState++;
      if (col == 4) {
        _subState = 0;
        // check parity bit on last packet
        if (_rowParity ^ _parityOdd) {
          // Parity error...start searching for header again
          setState(stSearchHdr);
        }

        _rowParity = false;
        if ((_nIdBits >> 2) == 10) {
          // We've got our 10 rows of data; switch to state to capture col parity
          setState(stColParity);
        }
      } else {
        _nIdBits++;
        _id = (_id << 1) + bit;
        _colParity[col] ^= bit;
      }
    }
    break;

  case stColParity:
    // We enter this state once for each col parity bit or until we register an
    // error. The later throws us back to looking for a header again.
    {
      unsigned col = _subState++;
      _colParity[col] ^= bit;

      if (_colParity[col] ^ _parityOdd) {
        // Column parity error, so reset
        setState(stSearchHdr);
      }

      if (col == 3) {
        setState(stGetStop);
      }
    }
    break;

  case stGetStop:
    if (bit) {
      // Everything was good, but we didn't get the stop bit so we are not
      // going to register a valid id.
    } else {
      // Got a valid id! Log it and flag it as valid.
      _lastId = _id;
      idReady = true;
    }
    setState(stSearchHdr);
    break;

  default:
    // If we get here, then something is seriously wrong. Attempt to recover
    // by reseting the state machine.
    setState(stReset);
    break;
  }
  return (idReady ? _lastId : 0);
}

// Set the power up defaults
void RFIDScanner::setDefaults()
{
  _invert        = false;
  _minPeakToPeak = 30;
  _minCalCount   = 32;
  _parityOdd     = false;
}


