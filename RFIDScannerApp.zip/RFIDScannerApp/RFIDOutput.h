// *****************************************************************************
// RFIDOutput
// ----------
// This class controls most of the RFID output functions. Specifically, it
// displays any valid id's on the serial monitor while also turning on and off
// applicable LED's while also generating a buzzer tone.
//
// The following LED's are controlled:
//    RED     To signify that the scanner is searching for valid signal and/or
//            attempting to calibrate the signal level and bit durations.
//
//    YELLOW  Signfies that we have a potentially good signal and the scanner is
//            searching for a valid id.
//
//    GREEN   Signifies that we have found a valid id.  This LED will stay on
//            so long as valid ids continue to be sent to this object.
//
// The buzzer will also sound when the Green LED is illuminated so long as
// the buzzer is enabled.  See code within on how to control buzzer duration
// and frqequency.  Refer to the implementation file for further details.
// -----------------------------------------------------------------------------
// Created by:  Curtis Ratzlaff  10/19/2012
// Copyright (C) 2012, 2013 by Carnegie Mellon University
// *****************************************************************************


class RFIDOutput {
public:
  // Indices to the various digital output port numbers
  enum Port {
    RED,        //index of red LED port
    YELLOW,     //index of yellow LED port
    GREEN,      //index of green LED port
    BUZZER,     //index of buzzer port
    // last
    MAX_PORTS   //The total number of ports we need to store
  };

  // The constructor sets up the port assignments for all LEDs and the buzzer
  RFIDOutput(int redPort = 6, int orangePort = 7, int greenPort = 8, int buzzerPort = 9);

  // Sounds the buzzer, if enabled and valid. This blocks for the duration
  // of the buzzer tone.  A duration of zero causes the current duration to be used.
  void buzz(int buzzDuration = 0);
  
  // Clears all output signals to LEDs and buzzer
  void clearAll();

  void turnOnGreen(bool on = true)  { setState(GREEN, on); }
  void turnOnRed(bool on = true)    { setState(RED, on); }
  void turnOnYellow(bool on = true) { setState(YELLOW, on); }
  
  // Called to indicate that a valid ID has been scanned. This will light the red
  // LED and sound the buzzer and also turn off other LEDs.
  void indicateValidId(uint64_t id);

  bool isOnGreen() const    { return isOn(GREEN); }
  bool isOn(Port p) const   { return _states[p] == HIGH; }
 
  // Output a 64-bit integer in hex or decimal format to serial monitor
  void print64(uint64_t v, int fmt, int nDigs = 0);
  
  // Reset this class to initial state
  void reset();

  // Setup the default buzzer duration and resonant frequency.
  void setBuzzerDuration(int durationMs, int buzzFreq = 2000);

  // Set state of a port.  If something is turned on, then all others are
  // first turned off.
  void setState(Port p, int statebool, bool turnOffOthers = true);
  
  // Run a visual and audible test of the LED's and buzzer
  void testLedsAndBuzzer();
  
  // Toggle state of port unconditionally
  void toggleState(Port p);
  
  // Update current output status based upon scanner state
  void updateState(int scannerState);
  
  // Private data to this object
private:  
  int _ports[MAX_PORTS];  //digital output ports of LEDs and buzzer
  int _states[MAX_PORTS]; //cache of existing state for quick check
  int _buzzDuration;      //desired length of tone (ms)
  int _buzzFreq;          //optimal buzzer freq (Hz)
};


// *****************************************************************************
//                        INLINE MEMBER FUNCTION IMPLEMENTATIONS
// *****************************************************************************

inline void RFIDOutput::clearAll()
{
  for (int i = 0; i < MAX_PORTS; i++) {
    digitalWrite(_ports[i], LOW);
    _states[i] = LOW;
  }     
}

// Called to indicate that a valid ID has been scanned
inline  void RFIDOutput::indicateValidId(uint64_t id)
{
  setState(GREEN, HIGH);
  Serial.print("valid id scanned: ");

  // Display the 10-digit hex id on the serial monitor (padded with leading 0's)
  print64(id, HEX, 10);
  Serial.println("");
  buzz();
}

// Setup the pin mode for all ports and turn them all off
inline void RFIDOutput::reset()
{
  for (int i = 0; i < MAX_PORTS; i++) {
    pinMode(_ports[i], OUTPUT);
  }
  clearAll();
}

// Set the state of a port, possibly turning off the others
inline void RFIDOutput::setState(Port p, int state, bool turnOffOthers)
{
  if (_states[p] == state) return;
  
  if (turnOffOthers && state) {
    clearAll();
  }
  digitalWrite(_ports[p], state);
  _states[p] = state;
}

// Unconditionally toggle the state of a port
inline void RFIDOutput::toggleState(Port p)
{
  setState(p, _states[p] == HIGH ? LOW : HIGH, false);
}

// Update output status based upon scanner state. The scanner header file
// must have been included to use this function.
inline void RFIDOutput::updateState(int scannerState)
{
  if (scannerState >= RFIDScanner::stSearchHdr) {
    turnOnYellow();
  } 
  else {
    turnOnRed();
  }
}


