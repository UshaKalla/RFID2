
Lab D RFIDScanner Notes
-----------------------
* This file contains the code for the Arduino used for the RFIDScanner
  portion of the lab.  
