// *****************************************************************************
// RFIDScanner
// -----------
// Class for the EM4102 type scanner
//
// This class and its implementation are used to scan for RFID id's in real-time
// on the Arduino or other suitable controller.   This class is not hardware
// specific.  The caller merely sends discrete sample levels to the 'sample'
// function of this class.
//
// After the class is instantiated, it should be set up with the appropriate
// parameters, though the defaults are generally okay for the EM4102 type
// RFID's.
// -----------------------------------------------------------------------------
// Created by:  Curtis Ratzlaff  10/19/2012
// Copyright (C) 2012, 2013 by Carnegie Mellon University
// *****************************************************************************

#ifndef RFIDScanner_h
#define RFIDScanner_h

#include "Arduino.h"
#include "limits.h"

class RFIDScanner {
public:
  // Constructor
  RFIDScanner();

public:
  // States for our state machine. See implementation for the meaning
  // of each of these states.
  enum State {
    stReset,
    stCalLevel,
    stCalBitLen,
    stSearchHdr,
    stGetPacket,
    stColParity,
    stGetStop
  };


  // *****************************************************************************
  // These properties must be set by the caller prior to first sample
  // *****************************************************************************
public:
  // Set to true if analog levels are inverted (lower amplitude = logical high)
  bool        _invert;

  // Minimum amplitude (counts) between pk-to-pk
  int16_t     _minPeakToPeak;

  // Minimum number of samples over which to calibrate initially. It
  // should be at least one bit length.
  uint8_t     _minCalCount;

  // Set to true for odd parity check; false for even parity
  bool        _parityOdd;

public:
  int getCurAvg() const {
    int avg = (_cur0Min + _cur1Max)/2;
    return _invert ? -avg : avg;
  }
  uint64_t getLastId() const     { return _lastId;  }
  uint8_t getState() const       { return _state; }
  
  void reset();
  uint64_t sample(int16_t lvl);
  void setDefaults();

private:
  void init();
  int16_t logSample(int16_t lvl, int8_t& dir, bool& bit);

  void setState(State st) {
    _state = uint8_t(st);
    _subState = 0;
  }

private:
  uint64_t    _id;            //will track the id currently be decoded
  uint64_t    _lastId;        //last valid id found
  int16_t     _prev0Min;      //previous min level for a low level
  int16_t     _prev1Max;      //previous max level for a high level
  int16_t     _cur0Min;       //current min level for low
  int16_t     _cur1Max;       //current max level for a high
  int16_t     _avgLvl;        //avg or median level being tracked
  uint8_t     _state;         //current state machine state
  uint8_t     _subState;      //sub-state used by some states
  uint8_t     _lastBitLen;    //length of last bit
  uint8_t     _bitLen;        //current bit length
  uint8_t     _bitLenMin;     //min length for a long bit
  uint8_t     _bitLenMax;     //max length for a short bit
  uint8_t     _nIdBits;       //# of id bits decoded so far
  uint8_t     _nHdrBits;      //# of header bits found so far
  bool        _isMid;         //indicates a mid-bit transition
  bool        _lastBit;       //state of last bit
  bool        _rowParity;     //current row parity
  bool        _colParity[4];  //current col parity


}; //class RFIDScanner


#endif



